package ajeffrey.teaching.minisoap;

public interface Remote { 

    public String getRemoteInterface ();

}
