package ajeffrey.teaching.test;

public interface TestMiniSoapIface {

    public void throwIt () throws TestMiniSoapException;

}
