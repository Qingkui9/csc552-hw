package ajeffrey.teaching.catalog;

public interface ViewFactory {

    public View build (Model model);

}
