package ajeffrey.teaching.catalog;

public interface ModelFactory {

    public Model build ();

}
