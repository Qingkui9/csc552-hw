package ajeffrey.teaching.catalog;

public interface Book {

    public String getTitle ();
    public String[] getKeywords ();

}
