package ajeffrey.teaching.hash.client;

import ajeffrey.teaching.hash.iface.Hash;

public interface GUIFactory {

    public GUI build (Hash hashTable);

}
