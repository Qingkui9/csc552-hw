package ajeffrey.teaching.util.buffer;

/**
 * An exception thrown when a buffer is empty
 * @author Alan Jeffrey
 * @version 1.0.1
 */
public class BufferEmptyException extends RuntimeException {
}
