package ajeffrey.teaching.util.lock;

public interface ReadWriteLockFactory {

    public ReadWriteLock build ();

}
