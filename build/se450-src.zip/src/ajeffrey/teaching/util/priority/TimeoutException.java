package ajeffrey.teaching.util.priority;

/**
 * An exception used when an operation times out.
 * @author Alan Jeffrey
 * @verion 1.0.1
 */
public class TimeoutException extends Exception {
}
