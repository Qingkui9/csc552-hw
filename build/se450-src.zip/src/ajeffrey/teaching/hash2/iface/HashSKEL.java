package ajeffrey.teaching.hash.iface;
